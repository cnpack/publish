# CnPack VCL Components

You can install [Delphinus package manager](https://github.com/Memnarch/Delphinus/wiki/Installing-Delphinus) and install CnPack VCL Components as a package there. (Delphinus-Support)

## Important!
**If you don't have Delphi Starter Edition** please open
_Source\Common\CnPack.inc_ and then:
- comment line `{$DEFINE PERSONAL_EDITION}`
- uncomment `{$DEFINE ENTERPRISE_EDITION}`
- rebuild both packages

# About CnPack Team
CnPack Team are Made up of Many Chinese Programmers and Delphi / C++ Builder Fans on Internet. Our products include CnPack IDE Wizards, CnPack VCL Components and CVSTracNT. etc. CnPack becomes Embarcadero Technology Partner in 2009.

CnPack Website: http://www.cnpack.org
CnPack BBS: http://bbs.cnpack.org
Email: master@cnpack.org
